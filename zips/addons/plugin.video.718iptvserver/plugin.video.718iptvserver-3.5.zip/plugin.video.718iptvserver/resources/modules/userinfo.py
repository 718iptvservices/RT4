import base64

addon_name   = base64.b64decode('NzE4IElQVFYgU0VSVkVS')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLjcxOGlwdHZzZXJ2ZXI=')

host         = base64.b64decode('aHR0cDovL2hpZ2gtcmVzb2x1dGlvbi5ldQ==')
port         = base64.b64decode('ODA4MA==')